import read #imports whatever fxns you wrote in read.py
from collections import Counter

test = read.foo()
df = read.load_data()
headlines = df["headline"]

if __name__ == "__main__":
#    print(headlines.iloc[0])
    headlines_list = []
    for i,v in headlines.iteritems():
        headlines_list.append(str(v))
    headlines_string = ' '.join(headlines_list)
    word_list = headlines_string.split()
#    print(word_list[0:10])
### Count words method 1
#    word_counts = {}
#    for w in word_list:
#        if w in word_counts:
#            word_counts[w] += 1
#        else:
#            word_counts[w] = 1

### Count words method 2
    print(Counter(word_list).most_common(100))
#
    
#    print(test)