import read

df = read.load_data()
urls = df["url"]

if __name__ == "__main__":
#    print(urls.head())
    print(urls.value_counts().head(100))