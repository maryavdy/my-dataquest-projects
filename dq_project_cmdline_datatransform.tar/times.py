import read
from dateutil.parser import parse
import datetime
from collections import Counter

df = read.load_data()
submit_times = df["submission_time"]

hours = []
def extract_hour(ser):
    for i,v in ser.iteritems():
        timestr = str(v)
        datetime = parse(timestr)
        #this should be a 'datetime.datetime' object
        hr = datetime.hour
        hours.append(hr)

if __name__ == "__main__":
#    print(submit_times.head())
#    for i,v in submit_times.iteritems():
#        timestr = str(v)
#        print(timestr)
        #output: 2013-05-14T00:57:34Z
#        datetime = parse(timestr)
        #this is a 'datetime.datetime' object
#        print(datetime)
        #output: 2013-05-14 00:57:34+00:00
#        print(datetime.hour)
        #output: 0
    extract_hour(submit_times)
#    print(hours)
    print(Counter(hours).most_common(10))
    
